package com.example

import com.example.data.WordGridGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class WordGridGeneratorTest {

    @Test
    fun testGridGenerationDimensionsAndWords() {
        val testWords = listOf("CAT", "DOG", "LION", "BEAR", "TIGER")
        val grid = WordGridGenerator.generate(
            availableWords = testWords,
            wordsCount = 3,
            gridSize = 8,
            level = 1
        )

        assertEquals(8, grid.size)
        assertEquals(8, grid.letters.size)
        assertEquals(8, grid.letters[0].size)
        assertEquals(3, grid.targetWords.size)
        assertEquals(3, grid.placedWords.size)

        // Verify each placed word has valid coordinates within 0..7
        for (placed in grid.placedWords) {
            assertEquals(placed.word.length, placed.coordinates.size)
            for (coord in placed.coordinates) {
                assertTrue(coord.row in 0..7)
                assertTrue(coord.col in 0..7)
            }

            // Verify characters in grid match the placed word
            val extracted = placed.coordinates.map { grid.letters[it.row][it.col] }.joinToString("")
            assertEquals(placed.word, extracted)
        }
    }
}
