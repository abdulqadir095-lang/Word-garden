package com.example

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AppScreen
import com.example.ui.GameViewModel
import com.example.ui.components.NoInternetOverlay
import com.example.ui.components.SoundSettingsDialog
import com.example.ui.screens.GameScreen
import com.example.ui.screens.MenuScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.util.AdManager
import com.example.util.NetworkMonitor
import com.google.android.gms.ads.MobileAds

class MainActivity : ComponentActivity() {
    private var isAppInitialized = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        try {
            MobileAds.initialize(applicationContext) {
                isAppInitialized = true
                AdManager.preloadAppOpenAd(applicationContext)
                AdManager.loadRewardedAd(applicationContext)
                AdManager.loadInterstitialAd(applicationContext)
                window.decorView.post {
                    if (!isFinishing && !isDestroyed) {
                        AdManager.onAppStart(this@MainActivity)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("MainActivity", "MobileAds initialization notice: ${e.message}")
        }

        setContent {
            MyApplicationTheme {
                KidsWordMasterApp()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (isAppInitialized) {
            AdManager.onAppStart(this)
        }
    }

    override fun onResume() {
        super.onResume()
        AdManager.loadRewardedAd(this)
        AdManager.loadInterstitialAd(this)
    }
}

@Composable
fun KidsWordMasterApp(
    viewModel: GameViewModel = viewModel()
) {
    val context = LocalContext.current
    val networkMonitor = remember { NetworkMonitor(context) }
    val isOnline by networkMonitor.isOnline.collectAsStateWithLifecycle()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var showSettingsDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        AdManager.loadRewardedAd(context)
        AdManager.loadInterstitialAd(context)
    }

    // Intercept back button when in GameScreen to return to Menu
    BackHandler(enabled = uiState.currentScreen == AppScreen.GAME) {
        viewModel.openMenu()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
            AnimatedContent(
                targetState = uiState.currentScreen,
                transitionSpec = {
                    if (targetState == AppScreen.GAME) {
                        (slideInHorizontally { width -> width } + fadeIn()).togetherWith(
                            slideOutHorizontally { width -> -width } + fadeOut()
                        )
                    } else {
                        (slideInHorizontally { width -> -width } + fadeIn()).togetherWith(
                            slideOutHorizontally { width -> width } + fadeOut()
                        )
                    }
                },
                label = "screen_transition",
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) { screen ->
                when (screen) {
                    AppScreen.MENU -> {
                        MenuScreen(
                            categoryProgressMap = uiState.categoryProgressMap,
                            totalStars = uiState.totalStars,
                            onSelectCategory = { category ->
                                viewModel.startCategory(category)
                            },
                            onOpenSettings = {
                                showSettingsDialog = true
                            }
                        )
                    }
                    AppScreen.GAME -> {
                        GameScreen(
                            state = uiState,
                            onBackToMenu = {
                                val activity = AdManager.findActivity(context)
                                if (viewModel.shouldShowInterstitial() && activity != null) {
                                    viewModel.consumeInterstitialAd()
                                    AdManager.showInterstitialAd(activity) {
                                        viewModel.openMenu()
                                    }
                                } else {
                                    viewModel.openMenu()
                                }
                            },
                            onTriggerHint = {
                                val activity = AdManager.findActivity(context)
                                if (activity != null) {
                                    AdManager.showRewardedAd(
                                        activity = activity,
                                        onRewardEarned = {
                                            viewModel.triggerHint()
                                        }
                                    )
                                } else {
                                    viewModel.triggerHint()
                                }
                            },
                            onNextLevel = {
                                val activity = AdManager.findActivity(context)
                                if (viewModel.shouldShowInterstitial() && activity != null) {
                                    viewModel.consumeInterstitialAd()
                                    AdManager.showInterstitialAd(activity) {
                                        viewModel.nextLevel()
                                    }
                                } else {
                                    viewModel.nextLevel()
                                }
                            },
                            onRechargeHearts = {
                                val activity = AdManager.findActivity(context)
                                if (activity != null) {
                                    AdManager.showRewardedAd(
                                        activity = activity,
                                        onRewardEarned = {
                                            viewModel.rechargeHearts()
                                        }
                                    )
                                } else {
                                    viewModel.rechargeHearts()
                                }
                            },
                            onToggleSound = { viewModel.toggleSound() },
                            onToggleVoice = { viewModel.toggleVoice() },
                            onSpeakWord = { word -> viewModel.speakWord(word) },
                            onCellTouchStart = { coord -> viewModel.onCellTouchStart(coord) },
                            onCellTouchMove = { coord -> viewModel.onCellTouchMove(coord) },
                            onCellTouchEnd = { viewModel.onCellTouchEnd() }
                        )
                    }
                }
            }

            if (showSettingsDialog) {
                SoundSettingsDialog(
                    soundEnabled = uiState.soundEnabled,
                    voiceEnabled = uiState.voiceEnabled,
                    onToggleSound = { viewModel.toggleSound() },
                    onToggleVoice = { viewModel.toggleVoice() },
                    onDismiss = { showSettingsDialog = false }
                )
            }
        }

        // Enforce online-only gameplay
        NoInternetOverlay(
            isOnline = isOnline,
            onRetry = { networkMonitor.checkConnectivity() }
        )
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MyApplicationTheme { Greeting("Android") }
}
