package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF673AB7)
val PurpleGrey40 = Color(0xFF5E35B1)
val Pink40 = Color(0xFFE91E63)

// Kid-Friendly Playful Palette
val CandyPink = Color(0xFFFF4081)
val DeepIndigo = Color(0xFF4A148C)
val SunnyGold = Color(0xFFFFD54F)
val BorderGold = Color(0xFFFFB300)
val FreshGreen = Color(0xFF4CAF50)
val ForestGreen = Color(0xFF2E7D32)
val SkyBlue = Color(0xFF29B6F6)
val DeepBlue = Color(0xFF0288D1)
val WarmOrange = Color(0xFFFF9800)
val SunsetRed = Color(0xFFFF5722)
val SoftBgPink = Color(0xFFFFF0F5)
val SoftBgCyan = Color(0xFFE0F7FA)
val GridBackground = Color(0xFFFF8F00)
val GridCellNormal = Color(0xFFFFFFFF)
val GridCellSelected = Color(0xFF2196F3)
val GridCellCorrect = Color(0xFF4CAF50)
val GridCellHint = Color(0xFFFFEB3B)
val TextDark = Color(0xFF311B92)
