package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.GameUiState
import com.example.ui.components.AdMobBanner
import com.example.ui.components.CelebrationOverlay
import com.example.ui.components.KidsTopBar
import com.example.ui.components.RechargeOverlay
import com.example.ui.components.SoundSettingsDialog
import com.example.ui.components.WordGrid
import com.example.ui.components.WordTargetPills
import com.example.ui.theme.BorderGold
import com.example.ui.theme.CandyPink
import com.example.ui.theme.DeepIndigo
import com.example.ui.theme.SunnyGold

@Composable
fun GameScreen(
    state: GameUiState,
    onBackToMenu: () -> Unit,
    onTriggerHint: () -> Unit,
    onNextLevel: () -> Unit,
    onRechargeHearts: () -> Unit,
    onToggleSound: () -> Unit,
    onToggleVoice: () -> Unit,
    onSpeakWord: (String) -> Unit,
    onCellTouchStart: (com.example.data.GridCoordinate) -> Unit,
    onCellTouchMove: (com.example.data.GridCoordinate) -> Unit,
    onCellTouchEnd: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showSettingsDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFFFDEE9), // Light candy pink
                        Color(0xFFB5FFFC)  // Light cyan
                    )
                )
            )
            .testTag("game_screen")
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Bar
                KidsTopBar(
                    level = state.level,
                    lives = state.lives,
                    score = state.score,
                    soundEnabled = state.soundEnabled,
                    onToggleSound = onToggleSound
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Category Title with Emoji
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .padding(vertical = 2.dp)
                        .testTag("active_category_title")
                ) {
                    Text(
                        text = state.selectedCategory.emoji,
                        fontSize = 22.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = state.selectedCategory.name.uppercase(),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = state.selectedCategory.themeColor
                    )
                }

                // Word Target Pills
                WordTargetPills(
                    targetWords = state.targetWords,
                    onSpeakWord = onSpeakWord
                )

                // Hint message if active
                AnimatedVisibility(
                    visible = state.hintMessage != null,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    state.hintMessage?.let { msg ->
                        Surface(
                            modifier = Modifier
                                .padding(vertical = 4.dp)
                                .shadow(3.dp, RoundedCornerShape(12.dp)),
                            shape = RoundedCornerShape(12.dp),
                            color = SunnyGold
                        ) {
                            Text(
                                text = msg,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = DeepIndigo,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Word Search Grid
                state.grid?.let { grid ->
                    WordGrid(
                        grid = grid,
                        selectedCoords = state.selectedCoords,
                        foundCoords = state.foundWordCoords,
                        hintedCoord = state.hintedCoord,
                        onCellTouchStart = onCellTouchStart,
                        onCellTouchMove = onCellTouchMove,
                        onCellTouchEnd = onCellTouchEnd,
                        frameColor = state.selectedCategory.themeColor
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Action Buttons Row: Menu & Hint
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Menu Button
                    OutlinedButton(
                        onClick = onBackToMenu,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("back_to_menu_button"),
                        shape = RoundedCornerShape(24.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = Color.White.copy(alpha = 0.9f)
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Menu",
                            tint = DeepIndigo
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Menu",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = DeepIndigo
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    // Hint Button
                    Button(
                        onClick = onTriggerHint,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .shadow(4.dp, RoundedCornerShape(24.dp))
                            .testTag("hint_button"),
                        shape = RoundedCornerShape(24.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SunnyGold)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = "Hint",
                            tint = DeepIndigo
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Hint 🎬",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            color = DeepIndigo
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            // Overlay: Level Completed
            if (state.isLevelCompleted) {
                CelebrationOverlay(
                    level = state.level,
                    score = state.score,
                    onNextLevel = onNextLevel,
                    onBackToMenu = onBackToMenu
                )
            }

            // Overlay: Out of Hearts (Reward ad only)
            if (state.isOutOfHeartsModalVisible) {
                RechargeOverlay(
                    onRechargeWithAd = onRechargeHearts,
                    onBackToMenu = onBackToMenu
                )
            }

            // Audio Settings Dialog
            if (showSettingsDialog) {
                SoundSettingsDialog(
                    soundEnabled = state.soundEnabled,
                    voiceEnabled = state.voiceEnabled,
                    onToggleSound = onToggleSound,
                    onToggleVoice = onToggleVoice,
                    onDismiss = { showSettingsDialog = false }
                )
            }
        }

        // Persistent Banner Ad: ca-app-pub-3208154945920359/5179222716 active in all time during gameplay
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(6.dp),
            color = Color.White.copy(alpha = 0.95f)
        ) {
            AdMobBanner(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp)
            )
        }
    }
}
