package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GeneratedGrid
import com.example.data.GridCoordinate
import com.example.ui.theme.DeepIndigo
import com.example.ui.theme.GridBackground
import com.example.ui.theme.GridCellCorrect
import com.example.ui.theme.GridCellHint
import com.example.ui.theme.GridCellNormal
import com.example.ui.theme.GridCellSelected
import kotlin.math.min

@Composable
fun WordGrid(
    grid: GeneratedGrid,
    selectedCoords: List<GridCoordinate>,
    foundCoords: Set<GridCoordinate>,
    hintedCoord: GridCoordinate?,
    onCellTouchStart: (GridCoordinate) -> Unit,
    onCellTouchMove: (GridCoordinate) -> Unit,
    onCellTouchEnd: () -> Unit,
    modifier: Modifier = Modifier,
    frameColor: Color = GridBackground
) {
    val infiniteTransition = rememberInfiniteTransition(label = "hint_pulse")
    val hintScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "hint_pulse_scale"
    )

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .widthIn(max = 420.dp)
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        val gridSize = grid.size
        val availableWidth = maxWidth - 16.dp
        val cellSize = availableWidth / gridSize

        // Outer Frame with 3D shadow and playful rounded corners
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .shadow(8.dp, RoundedCornerShape(20.dp))
                .testTag("word_grid_container"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = frameColor)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
                    .pointerInput(gridSize) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                val cSizePx = size.width / gridSize
                                val row = (offset.y / cSizePx).toInt().coerceIn(0, gridSize - 1)
                                val col = (offset.x / cSizePx).toInt().coerceIn(0, gridSize - 1)
                                onCellTouchStart(GridCoordinate(row, col))
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val cSizePx = size.width / gridSize
                                val row = (change.position.y / cSizePx).toInt().coerceIn(0, gridSize - 1)
                                val col = (change.position.x / cSizePx).toInt().coerceIn(0, gridSize - 1)
                                onCellTouchMove(GridCoordinate(row, col))
                            },
                            onDragEnd = {
                                onCellTouchEnd()
                            },
                            onDragCancel = {
                                onCellTouchEnd()
                            }
                        )
                    }
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (r in 0 until gridSize) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            for (c in 0 until gridSize) {
                                val coord = GridCoordinate(r, c)
                                val letter = grid.letters[r][c]
                                val isSelected = selectedCoords.contains(coord)
                                val isFound = foundCoords.contains(coord)
                                val isHinted = hintedCoord == coord

                                val cellBg by animateColorAsState(
                                    targetValue = when {
                                        isSelected -> GridCellSelected
                                        isFound -> GridCellCorrect
                                        isHinted -> GridCellHint
                                        else -> GridCellNormal
                                    },
                                    label = "cell_color_${r}_$c"
                                )

                                val textColor = when {
                                    isSelected || isFound -> Color.White
                                    isHinted -> Color.Black
                                    else -> DeepIndigo
                                }

                                val cellScale = if (isHinted) hintScale else if (isSelected) 1.05f else 1.0f

                                Box(
                                    modifier = Modifier
                                        .size(cellSize - 3.dp)
                                        .scale(cellScale)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(cellBg)
                                        .then(
                                            if (isHinted) {
                                                Modifier.border(2.dp, Color(0xFFFF6F00), RoundedCornerShape(8.dp))
                                            } else if (!isSelected && !isFound) {
                                                Modifier.border(BorderStroke(1.dp, Color(0xFFE0E0E0)), RoundedCornerShape(8.dp))
                                            } else {
                                                Modifier
                                            }
                                        )
                                        .testTag("cell_${r}_$c"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    // 3D bottom bevel indicator for tactile tactile feeling
                                    if (!isSelected && !isFound) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .size(3.dp)
                                                .align(Alignment.BottomCenter)
                                                .background(Color(0xFFDDDDDD))
                                        )
                                    }

                                    Text(
                                        text = letter.toString(),
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black,
                                        color = textColor
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
