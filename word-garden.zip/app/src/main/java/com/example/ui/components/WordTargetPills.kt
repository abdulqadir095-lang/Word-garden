package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TargetWordState
import com.example.ui.theme.BorderGold
import com.example.ui.theme.DeepIndigo
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.FreshGreen

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WordTargetPills(
    targetWords: List<TargetWordState>,
    onSpeakWord: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    FlowRow(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        targetWords.forEach { target ->
            val isFound = target.isFound

            val bgColor by animateColorAsState(
                targetValue = if (isFound) FreshGreen else Color.White,
                label = "pill_bg_${target.word}"
            )
            val textColor by animateColorAsState(
                targetValue = if (isFound) Color.White else DeepIndigo,
                label = "pill_text_${target.word}"
            )
            val borderColor = if (isFound) ForestGreen else BorderGold

            Surface(
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .shadow(if (isFound) 1.dp else 3.dp, shape = RoundedCornerShape(20.dp))
                    .clickable { onSpeakWord(target.word) }
                    .testTag("word_target_${target.word}"),
                shape = RoundedCornerShape(20.dp),
                color = bgColor,
                border = BorderStroke(2.dp, borderColor)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isFound) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Word Found",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    } else {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Pronounce Word",
                            tint = BorderGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }

                    Text(
                        text = target.word,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = textColor,
                        textDecoration = if (isFound) TextDecoration.LineThrough else TextDecoration.None
                    )
                }
            }
        }
    }
}
