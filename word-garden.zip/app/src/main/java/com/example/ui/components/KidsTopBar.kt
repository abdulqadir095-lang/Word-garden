package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderGold
import com.example.ui.theme.CandyPink
import com.example.ui.theme.DeepIndigo
import com.example.ui.theme.SunnyGold

@Composable
fun KidsTopBar(
    level: Int,
    lives: Int,
    score: Int,
    soundEnabled: Boolean,
    onToggleSound: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .shadow(4.dp, shape = RoundedCornerShape(18.dp)),
        color = Color.White.copy(alpha = 0.95f),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Level Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(CandyPink)
                    .padding(horizontal = 10.dp, vertical = 5.dp)
                    .testTag("level_badge")
            ) {
                Text(
                    text = "Lvl: $level",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }

            // Lives (Hearts) Display
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(3.dp),
                modifier = Modifier.testTag("lives_display")
            ) {
                for (i in 1..3) {
                    val isAlive = i <= lives
                    val heartScale by animateFloatAsState(
                        targetValue = if (isAlive) 1f else 0.85f,
                        animationSpec = spring(dampingRatio = 0.6f),
                        label = "heart_scale"
                    )
                    Text(
                        text = if (isAlive) "❤️" else "🖤",
                        fontSize = 18.sp,
                        modifier = Modifier.scale(heartScale)
                    )
                }
            }

            // Score with Star
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(SunnyGold.copy(alpha = 0.25f))
                    .padding(horizontal = 8.dp, vertical = 5.dp)
                    .testTag("score_display")
            ) {
                Text(text = "⭐", fontSize = 14.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "$score",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = DeepIndigo
                )
            }

            // Sound Toggle Icon Button
            IconButton(
                onClick = onToggleSound,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (soundEnabled) SunnyGold else Color.LightGray.copy(alpha = 0.4f))
                    .testTag("sound_toggle_button")
            ) {
                Icon(
                    imageVector = if (soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                    contentDescription = "Sound Settings",
                    tint = DeepIndigo,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
