package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CandyPink
import com.example.ui.theme.DeepIndigo
import com.example.ui.theme.FreshGreen
import com.example.ui.theme.SkyBlue
import com.example.ui.theme.SunnyGold
import com.example.ui.theme.WarmOrange
import kotlin.random.Random

data class ConfettiParticle(
    val x: Float,
    val initialY: Float,
    val speed: Float,
    val size: Float,
    val color: Color,
    val isCircle: Boolean
)

@Composable
fun CelebrationOverlay(
    level: Int,
    score: Int,
    onNextLevel: () -> Unit,
    onBackToMenu: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scaleAnim = remember { Animatable(0.2f) }

    LaunchedEffect(Unit) {
        scaleAnim.animateTo(
            targetValue = 1f,
            animationSpec = tween(500, easing = FastOutSlowInEasing)
        )
    }

    // Generate random confetti particles
    val particles = remember {
        val colors = listOf(CandyPink, SunnyGold, FreshGreen, SkyBlue, WarmOrange, Color(0xFFE91E63))
        List(50) {
            ConfettiParticle(
                x = Random.nextFloat(),
                initialY = Random.nextFloat() * -0.5f,
                speed = 0.3f + Random.nextFloat() * 0.7f,
                size = 12f + Random.nextFloat() * 16f,
                color = colors.random(),
                isCircle = Random.nextBoolean()
            )
        }
    }

    val animProgress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        animProgress.animateTo(
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(2500, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            )
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.65f))
            .testTag("celebration_overlay"),
        contentAlignment = Alignment.Center
    ) {
        // Confetti Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val progress = animProgress.value

            particles.forEach { p ->
                val currentY = ((p.initialY + progress * p.speed * 1.5f) % 1.2f) * h
                val currentX = (p.x * w + sinOffset(progress, p.speed) * 40f)

                if (p.isCircle) {
                    drawCircle(
                        color = p.color,
                        radius = p.size / 2,
                        center = Offset(currentX, currentY)
                    )
                } else {
                    drawRect(
                        color = p.color,
                        topLeft = Offset(currentX, currentY),
                        size = Size(p.size, p.size * 0.6f)
                    )
                }
            }
        }

        // Celebration Card
        Card(
            modifier = Modifier
                .fillMaxWidth(0.88f)
                .scale(scaleAnim.value)
                .shadow(16.dp, RoundedCornerShape(28.dp))
                .testTag("celebration_card"),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "🎉 FANTASTIC! 🎉",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    color = CandyPink,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(10.dp))

                // 3 Stars Row
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "⭐", fontSize = 38.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "⭐", fontSize = 48.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "⭐", fontSize = 38.sp)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Level $level Completed!",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepIndigo
                )

                Text(
                    text = "Total Score: $score",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Next Level Button
                Button(
                    onClick = onNextLevel,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .shadow(6.dp, RoundedCornerShape(26.dp))
                        .testTag("next_level_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = FreshGreen),
                    shape = RoundedCornerShape(26.dp)
                ) {
                    Text(
                        text = "NEXT LEVEL ➔",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedButton(
                    onClick = onBackToMenu,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("celebration_menu_button"),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Text(
                        text = "Choose Another Category",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = DeepIndigo
                    )
                }
            }
        }
    }
}

private fun sinOffset(progress: Float, factor: Float): Float {
    return kotlin.math.sin((progress * 2 * Math.PI * factor).toDouble()).toFloat()
}
