package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CategoryInfo
import com.example.data.GameDataset
import com.example.data.GeneratedGrid
import com.example.data.GridCoordinate
import com.example.data.PlacedWord
import com.example.data.SoundManager
import com.example.data.WordGridGenerator
import com.example.data.local.CategoryProgressDao
import com.example.data.local.CategoryProgressEntity
import com.example.data.local.GameDatabase
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max

enum class AppScreen {
    MENU,
    GAME
}

data class TargetWordState(
    val word: String,
    val isFound: Boolean = false,
    val coordinates: List<GridCoordinate> = emptyList()
)

data class GameUiState(
    val currentScreen: AppScreen = AppScreen.MENU,
    val selectedCategory: CategoryInfo = GameDataset.categories.first(),
    val level: Int = 1,
    val score: Int = 0,
    val highScore: Int = 0,
    val lives: Int = 3,
    val wrongAttempts: Int = 0,
    val grid: GeneratedGrid? = null,
    val targetWords: List<TargetWordState> = emptyList(),
    val selectedCoords: List<GridCoordinate> = emptyList(),
    val foundWordCoords: Set<GridCoordinate> = emptySet(),
    val hintedCoord: GridCoordinate? = null,
    val hintMessage: String? = null,
    val isLevelCompleted: Boolean = false,
    val isOutOfHeartsModalVisible: Boolean = false,
    val soundEnabled: Boolean = true,
    val voiceEnabled: Boolean = true,
    val totalStars: Int = 0,
    val categoryProgressMap: Map<String, CategoryProgressEntity> = emptyMap(),
    val clearedLevelsCount: Int = 0,
    val pendingInterstitial: Boolean = false
)

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val dao: CategoryProgressDao = GameDatabase.getInstance(application).categoryProgressDao()
    val soundManager = SoundManager(application)

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private var penaltyJob: Job? = null
    private var hintClearJob: Job? = null
    private var dragStartCoord: GridCoordinate? = null

    init {
        // Collect saved category progress from Room database
        viewModelScope.launch {
            dao.getAllProgress().collect { progressList ->
                val map = progressList.associateBy { it.categoryId }
                val totalStars = progressList.sumOf { it.starsEarned }
                _uiState.update { current ->
                    val currentCatProgress = map[current.selectedCategory.id]
                    current.copy(
                        categoryProgressMap = map,
                        totalStars = totalStars,
                        highScore = max(current.highScore, currentCatProgress?.highScore ?: 0)
                    )
                }
            }
        }
    }

    fun openMenu() {
        _uiState.update { it.copy(currentScreen = AppScreen.MENU) }
    }

    fun startCategory(category: CategoryInfo) {
        val saved = _uiState.value.categoryProgressMap[category.id]
        val startLevel = saved?.maxLevel ?: 1
        val savedHighScore = saved?.highScore ?: 0

        _uiState.update {
            it.copy(
                currentScreen = AppScreen.GAME,
                selectedCategory = category,
                level = startLevel,
                score = 0,
                highScore = savedHighScore,
                lives = 3,
                wrongAttempts = 0,
                isLevelCompleted = false,
                isOutOfHeartsModalVisible = false,
                hintedCoord = null,
                hintMessage = null
            )
        }
        initLevel(category, startLevel)
    }

    fun restartCurrentCategory() {
        startCategory(_uiState.value.selectedCategory)
    }

    fun initLevel(category: CategoryInfo = _uiState.value.selectedCategory, level: Int = _uiState.value.level) {
        val wordsCount = when {
            level <= 2 -> 3
            level <= 5 -> 4
            else -> 4
        }
        val generated = WordGridGenerator.generate(
            availableWords = category.words,
            wordsCount = wordsCount,
            gridSize = 8,
            level = level
        )

        val targets = generated.placedWords.map { pw ->
            TargetWordState(
                word = pw.word,
                isFound = false,
                coordinates = pw.coordinates
            )
        }

        _uiState.update {
            it.copy(
                grid = generated,
                targetWords = targets,
                selectedCoords = emptyList(),
                foundWordCoords = emptySet(),
                hintedCoord = null,
                hintMessage = null,
                isLevelCompleted = false
            )
        }
    }

    fun onCellTouchStart(coord: GridCoordinate) {
        if (_uiState.value.lives <= 0 || _uiState.value.isLevelCompleted) return
        dragStartCoord = coord
        soundManager.playTap()
        _uiState.update { it.copy(selectedCoords = listOf(coord)) }
    }

    fun onCellTouchMove(coord: GridCoordinate) {
        if (_uiState.value.lives <= 0 || _uiState.value.isLevelCompleted) return
        val start = dragStartCoord ?: return
        val line = calculateLine(start, coord)
        if (line != _uiState.value.selectedCoords) {
            _uiState.update { it.copy(selectedCoords = line) }
        }
    }

    fun onCellTouchEnd() {
        val selected = _uiState.value.selectedCoords
        dragStartCoord = null
        if (selected.isEmpty()) return

        val grid = _uiState.value.grid ?: return
        val letters = grid.letters

        val forwardWord = selected.map { letters[it.row][it.col] }.joinToString("")
        val reverseWord = forwardWord.reversed()

        val state = _uiState.value
        val matchedTarget = state.targetWords.firstOrNull { target ->
            !target.isFound && (target.word.equals(forwardWord, ignoreCase = true) || target.word.equals(reverseWord, ignoreCase = true))
        }

        if (matchedTarget != null) {
            // Correct word match!
            val updatedTargets = state.targetWords.map {
                if (it.word == matchedTarget.word) it.copy(isFound = true) else it
            }
            val newFoundCoords = state.foundWordCoords + selected
            val newScore = state.score + 10
            val newHighScore = max(state.highScore, newScore)
            val allFound = updatedTargets.all { it.isFound }
            val newClearedCount = if (allFound) state.clearedLevelsCount + 1 else state.clearedLevelsCount
            val shouldTriggerInterstitial = allFound && (newClearedCount % 2 == 0)

            _uiState.update {
                it.copy(
                    targetWords = updatedTargets,
                    foundWordCoords = newFoundCoords,
                    selectedCoords = emptyList(),
                    score = newScore,
                    highScore = newHighScore,
                    wrongAttempts = 0,
                    hintedCoord = null,
                    hintMessage = null,
                    isLevelCompleted = allFound,
                    clearedLevelsCount = newClearedCount,
                    pendingInterstitial = shouldTriggerInterstitial
                )
            }

            soundManager.playCorrect()
            soundManager.speakWord(matchedTarget.word, praise = true)

            if (allFound) {
                soundManager.playWinFanfare()
                saveCategoryProgress(
                    categoryId = state.selectedCategory.id,
                    level = state.level + 1,
                    highScore = newHighScore,
                    wordsAdded = updatedTargets.size,
                    starsEarned = 1
                )
            }
        } else {
            // Wrong attempt: One mistake ends one life!
            soundManager.playError()
            val newLives = max(0, state.lives - 1)
            _uiState.update {
                it.copy(
                    selectedCoords = emptyList(),
                    wrongAttempts = 0,
                    lives = newLives
                )
            }
            if (newLives <= 0) {
                triggerPenaltyCountdown()
            }
        }
    }

    private fun calculateLine(start: GridCoordinate, end: GridCoordinate): List<GridCoordinate> {
        val dRow = end.row - start.row
        val dCol = end.col - start.col

        val stepRow = when {
            dRow > 0 -> 1
            dRow < 0 -> -1
            else -> 0
        }
        val stepCol = when {
            dCol > 0 -> 1
            dCol < 0 -> -1
            else -> 0
        }

        // Check if pure horizontal, pure vertical, or 45-degree diagonal
        val isHorizontal = dRow == 0
        val isVertical = dCol == 0
        val isDiagonal = abs(dRow) == abs(dCol)

        if (!isHorizontal && !isVertical && !isDiagonal) {
            // If dragging arbitrarily, project to dominant direction for responsive UX
            return if (abs(dRow) > abs(dCol)) {
                // Vertical dominant
                val length = abs(dRow)
                (0..length).map { i -> GridCoordinate(start.row + i * stepRow, start.col) }
            } else {
                // Horizontal dominant
                val length = abs(dCol)
                (0..length).map { i -> GridCoordinate(start.row, start.col + i * stepCol) }
            }
        }

        val steps = max(abs(dRow), abs(dCol))
        return (0..steps).map { i ->
            GridCoordinate(start.row + i * stepRow, start.col + i * stepCol)
        }
    }

    fun nextLevel() {
        val nextLvl = _uiState.value.level + 1
        _uiState.update {
            it.copy(
                level = nextLvl,
                isLevelCompleted = false,
                pendingInterstitial = false
            )
        }
        initLevel(_uiState.value.selectedCategory, nextLvl)
    }

    fun shouldShowInterstitial(): Boolean {
        return _uiState.value.pendingInterstitial
    }

    fun consumeInterstitialAd() {
        _uiState.update { it.copy(pendingInterstitial = false) }
    }

    fun triggerHint() {
        val state = _uiState.value
        if (state.lives <= 0 || state.isLevelCompleted) return

        val unFound = state.targetWords.firstOrNull { !it.isFound } ?: return
        val placed = state.grid?.placedWords?.firstOrNull { it.word == unFound.word } ?: return
        val firstCoord = placed.coordinates.firstOrNull() ?: return
        val firstLetter = unFound.word.first()

        hintClearJob?.cancel()
        _uiState.update {
            it.copy(
                hintedCoord = firstCoord,
                hintMessage = "Look for '$firstLetter' in '${unFound.word}'! 💡"
            )
        }
        soundManager.playTap()

        hintClearJob = viewModelScope.launch {
            delay(5000)
            _uiState.update {
                if (it.hintedCoord == firstCoord) it.copy(hintedCoord = null, hintMessage = null) else it
            }
        }
    }

    fun speakWord(word: String) {
        soundManager.speakWord(word, praise = false)
    }

    private fun triggerPenaltyCountdown() {
        _uiState.update {
            it.copy(isOutOfHeartsModalVisible = true)
        }
    }

    fun rechargeHearts() {
        _uiState.update {
            it.copy(
                lives = 3,
                wrongAttempts = 0,
                isOutOfHeartsModalVisible = false
            )
        }
        soundManager.playWinFanfare()
    }

    fun toggleSound() {
        val newState = !_uiState.value.soundEnabled
        soundManager.soundEffectsEnabled = newState
        _uiState.update { it.copy(soundEnabled = newState) }
    }

    fun toggleVoice() {
        val newState = !_uiState.value.voiceEnabled
        soundManager.voicePronounceEnabled = newState
        _uiState.update { it.copy(voiceEnabled = newState) }
    }

    private fun saveCategoryProgress(
        categoryId: String,
        level: Int,
        highScore: Int,
        wordsAdded: Int,
        starsEarned: Int
    ) {
        viewModelScope.launch {
            val current = dao.getProgressForCategory(categoryId)
            val updated = CategoryProgressEntity(
                categoryId = categoryId,
                maxLevel = max(level, current?.maxLevel ?: 1),
                highScore = max(highScore, current?.highScore ?: 0),
                wordsFound = (current?.wordsFound ?: 0) + wordsAdded,
                starsEarned = (current?.starsEarned ?: 0) + starsEarned
            )
            dao.insertOrUpdate(updated)
        }
    }

    override fun onCleared() {
        super.onCleared()
        penaltyJob?.cancel()
        hintClearJob?.cancel()
        soundManager.release()
    }
}
