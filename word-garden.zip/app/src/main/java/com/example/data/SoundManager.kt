package com.example.data

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.PI
import kotlin.math.sin

class SoundManager(context: Context) {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    var soundEffectsEnabled: Boolean = true
    var voicePronounceEnabled: Boolean = true

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.let { engine ->
                    val result = engine.setLanguage(Locale.US)
                    if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                        engine.setPitch(1.15f) // Friendly cheerful tone for kids
                        engine.setSpeechRate(0.85f) // Clear articulation for learning
                        isTtsReady = true
                    }
                }
            } else {
                Log.w("SoundManager", "TTS initialization failed status: $status")
            }
        }
    }

    fun playCorrect() {
        if (!soundEffectsEnabled) return
        scope.launch {
            // Chime: 587 Hz (D5) to 880 Hz (A5) ascending tone
            val sampleRate = 44100
            val durationSec = 0.35
            val totalSamples = (sampleRate * durationSec).toInt()
            val buffer = ShortArray(totalSamples)

            for (i in 0 until totalSamples) {
                val t = i.toDouble() / sampleRate
                val progress = t / durationSec
                val freq = 587.33 + (880.00 - 587.33) * progress
                val envelope = (1.0 - progress) * 0.7
                val sample = sin(2.0 * PI * freq * t) * envelope
                buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
            }
            playPcm(buffer, sampleRate)
        }
    }

    fun playError() {
        if (!soundEffectsEnabled) return
        scope.launch {
            // Low bonk / wobble tone: 150 Hz sliding down to 70 Hz
            val sampleRate = 44100
            val durationSec = 0.25
            val totalSamples = (sampleRate * durationSec).toInt()
            val buffer = ShortArray(totalSamples)

            for (i in 0 until totalSamples) {
                val t = i.toDouble() / sampleRate
                val progress = t / durationSec
                val freq = 150.0 - (150.0 - 70.0) * progress
                val envelope = (1.0 - progress) * 0.6
                // Triangle-like waveform
                val phase = (freq * t) % 1.0
                val tri = if (phase < 0.5) (4.0 * phase - 1.0) else (3.0 - 4.0 * phase)
                val sample = tri * envelope
                buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
            }
            playPcm(buffer, sampleRate)
        }
    }

    fun playWinFanfare() {
        if (!soundEffectsEnabled) return
        scope.launch {
            // Major triad arpeggio: C5 (523), E5 (659), G5 (784), High C6 (1046)
            val sampleRate = 44100
            val noteDuration = 0.12
            val notes = listOf(523.25, 659.25, 783.99, 1046.50)
            val totalSamples = (sampleRate * noteDuration * notes.size).toInt()
            val buffer = ShortArray(totalSamples)

            var sampleIndex = 0
            for (freq in notes) {
                val noteSamples = (sampleRate * noteDuration).toInt()
                for (i in 0 until noteSamples) {
                    if (sampleIndex >= totalSamples) break
                    val t = i.toDouble() / sampleRate
                    val env = (1.0 - (i.toDouble() / noteSamples) * 0.4) * 0.6
                    val sample = sin(2.0 * PI * freq * t) * env
                    buffer[sampleIndex++] = (sample * Short.MAX_VALUE).toInt().toShort()
                }
            }
            playPcm(buffer, sampleRate)
        }
    }

    fun playTap() {
        if (!soundEffectsEnabled) return
        scope.launch {
            val sampleRate = 44100
            val durationSec = 0.04
            val totalSamples = (sampleRate * durationSec).toInt()
            val buffer = ShortArray(totalSamples)
            for (i in 0 until totalSamples) {
                val t = i.toDouble() / sampleRate
                val env = 1.0 - (i.toDouble() / totalSamples)
                val sample = sin(2.0 * PI * 800.0 * t) * env * 0.25
                buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
            }
            playPcm(buffer, sampleRate)
        }
    }

    fun speakWord(word: String, praise: Boolean = false) {
        if (!voicePronounceEnabled || !isTtsReady) return
        val textToSpeak = if (praise) {
            val praises = listOf("Awesome!", "Great job!", "Super!", "You found it!", "Brilliant!")
            "$word! ${praises.random()}"
        } else {
            word
        }
        tts?.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, null, "WORD_ID_${System.currentTimeMillis()}")
    }

    private fun playPcm(buffer: ShortArray, sampleRate: Int) {
        try {
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(buffer, 0, buffer.size)
            track.play()
            // Release after completion
            scope.launch {
                val durationMs = (buffer.size * 1000L) / sampleRate + 150
                kotlinx.coroutines.delay(durationMs)
                try {
                    track.stop()
                    track.release()
                } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            Log.e("SoundManager", "Error playing PCM audio", e)
        }
    }

    fun release() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {}
    }
}
