package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "category_progress")
data class CategoryProgressEntity(
    @PrimaryKey
    val categoryId: String,
    val maxLevel: Int = 1,
    val highScore: Int = 0,
    val wordsFound: Int = 0,
    val starsEarned: Int = 0
)
