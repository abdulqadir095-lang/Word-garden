package com.example.data

import kotlin.random.Random

data class GridCoordinate(val row: Int, val col: Int)

data class PlacedWord(
    val word: String,
    val coordinates: List<GridCoordinate>
)

data class GeneratedGrid(
    val size: Int,
    val letters: List<List<Char>>,
    val targetWords: List<String>,
    val placedWords: List<PlacedWord>
)

object WordGridGenerator {
    private const val DEFAULT_GRID_SIZE = 8
    private val LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

    // Directions: Horizontal (Right, Left), Vertical (Down, Up), Diagonal (Down-Right, Up-Left, Down-Left, Up-Right)
    private val DIRECTIONS = listOf(
        Pair(0, 1),   // Left to Right
        Pair(1, 0),   // Top to Bottom
        Pair(1, 1),   // Diagonal Down-Right
        Pair(0, -1),  // Right to Left
        Pair(-1, 0),  // Bottom to Top
        Pair(1, -1)   // Diagonal Down-Left
    )

    fun generate(
        availableWords: List<String>,
        wordsCount: Int = 3,
        gridSize: Int = DEFAULT_GRID_SIZE,
        level: Int = 1
    ): GeneratedGrid {
        // For early levels (1-3), keep directions simple (horizontal & vertical)
        val activeDirections = if (level <= 2) {
            listOf(Pair(0, 1), Pair(1, 0))
        } else if (level <= 5) {
            listOf(Pair(0, 1), Pair(1, 0), Pair(1, 1), Pair(0, -1))
        } else {
            DIRECTIONS
        }

        // Shuffle words and pick words that fit inside gridSize
        val eligibleWords = availableWords
            .map { it.uppercase().trim() }
            .filter { it.length in 3..gridSize }
            .shuffled()

        val selectedWords = eligibleWords.take(wordsCount)
        val matrix = Array(gridSize) { Array(gridSize) { ' ' } }
        val placedList = mutableListOf<PlacedWord>()

        for (word in selectedWords) {
            var placed = false
            var attempts = 0

            while (!placed && attempts < 150) {
                attempts++
                val dir = activeDirections.random()
                val dRow = dir.first
                val dCol = dir.second

                // Calculate valid starting bounds
                val minRow = if (dRow >= 0) 0 else (word.length - 1)
                val maxRow = if (dRow <= 0) gridSize - 1 else gridSize - word.length
                val minCol = if (dCol >= 0) 0 else (word.length - 1)
                val maxCol = if (dCol <= 0) gridSize - 1 else gridSize - word.length

                if (minRow > maxRow || minCol > maxCol) continue

                val startRow = Random.nextInt(minRow, maxRow + 1)
                val startCol = Random.nextInt(minCol, maxCol + 1)

                var canPlace = true
                val coords = mutableListOf<GridCoordinate>()

                for (i in word.indices) {
                    val r = startRow + i * dRow
                    val c = startCol + i * dCol
                    val existing = matrix[r][c]
                    if (existing != ' ' && existing != word[i]) {
                        canPlace = false
                        break
                    }
                    coords.add(GridCoordinate(r, c))
                }

                if (canPlace) {
                    for (i in word.indices) {
                        val coord = coords[i]
                        matrix[coord.row][coord.col] = word[i]
                    }
                    placedList.add(PlacedWord(word, coords))
                    placed = true
                }
            }
        }

        // Fill remaining empty cells with random letters
        val finalLetters = List(gridSize) { r ->
            List(gridSize) { c ->
                if (matrix[r][c] != ' ') {
                    matrix[r][c]
                } else {
                    LETTERS.random()
                }
            }
        }

        return GeneratedGrid(
            size = gridSize,
            letters = finalLetters,
            targetWords = placedList.map { it.word },
            placedWords = placedList
        )
    }
}
