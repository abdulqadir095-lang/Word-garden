package com.example.data

import androidx.compose.ui.graphics.Color

data class CategoryInfo(
    val id: String,
    val name: String,
    val emoji: String,
    val themeColor: Color,
    val words: List<String>
)

object GameDataset {
    val categories: List<CategoryInfo> = listOf(
        CategoryInfo(
            id = "ANIMALS",
            name = "Animals",
            emoji = "🦁",
            themeColor = Color(0xFFFF7043),
            words = listOf("LION", "TIGER", "BEAR", "DEER", "WOLF", "FOX", "COW", "DOG", "CAT", "PIG", "GOAT", "HARE", "FROG", "ZEBRA", "HORSE", "CAMEL", "PANDA", "MONKEY", "RABBIT")
        ),
        CategoryInfo(
            id = "FRUITS",
            name = "Fruits",
            emoji = "🍎",
            themeColor = Color(0xFFFF5252),
            words = listOf("APPLE", "MANGO", "BANANA", "GRAPES", "BERRY", "PEACH", "PLUM", "PEAR", "LEMON", "LIME", "KIWI", "MELON", "DATE", "FIGS", "GUAVA", "PAPAYA", "CHERRY", "ORANGE")
        ),
        CategoryInfo(
            id = "COLORS",
            name = "Colors",
            emoji = "🎨",
            themeColor = Color(0xFFAB47BC),
            words = listOf("RED", "BLUE", "GREEN", "PINK", "BLACK", "WHITE", "GOLD", "GREY", "BROWN", "NAVY", "AQUA", "TEAL", "LIME", "OLIVE", "CORAL", "CYAN", "BEIGE", "PURPLE")
        ),
        CategoryInfo(
            id = "VEHICLES",
            name = "Vehicles",
            emoji = "🚗",
            themeColor = Color(0xFF29B6F6),
            words = listOf("CAR", "BUS", "VAN", "TRAIN", "BOAT", "SHIP", "JEEP", "BIKE", "TAXI", "TRAM", "TRUCK", "METRO", "ROCKET", "PLANE", "SCOOTER", "CYCLE")
        ),
        CategoryInfo(
            id = "SHAPES",
            name = "Shapes",
            emoji = "⭐",
            themeColor = Color(0xFFFFA726),
            words = listOf("OVAL", "CONE", "CUBE", "LINE", "RING", "STAR", "HEART", "CROSS", "WAVE", "DISK", "PIE", "ARC", "HEXA", "SPHERE", "SQUARE", "ROUND")
        ),
        CategoryInfo(
            id = "BIRDS",
            name = "Birds",
            emoji = "🦜",
            themeColor = Color(0xFF26A69A),
            words = listOf("CROW", "DOVE", "DUCK", "OWL", "SWAN", "HAWK", "EAGLE", "ROBIN", "PARROT", "PIGEON", "FALCON", "GULL")
        ),
        CategoryInfo(
            id = "VEGETABLES",
            name = "Vegetables",
            emoji = "🥕",
            themeColor = Color(0xFF66BB6A),
            words = listOf("POTATO", "TOMATO", "CARROT", "ONION", "GARLIC", "GINGER", "RADISH", "PEAS", "BEANS", "CORN", "CHILI", "SPINACH", "CUCUMBER")
        ),
        CategoryInfo(
            id = "FLOWERS",
            name = "Flowers",
            emoji = "🌸",
            themeColor = Color(0xFFEC407A),
            words = listOf("ROSE", "LILY", "LOTUS", "TULIP", "DAISY", "ORCHID", "VIOLET", "JASMINE", "SUNFLOWER", "IRIS")
        ),
        CategoryInfo(
            id = "SPORTS",
            name = "Sports",
            emoji = "⚽",
            themeColor = Color(0xFF42A5F5),
            words = listOf("CHESS", "LUDO", "GOLF", "POLO", "CRICKET", "TENNIS", "HOCKEY", "BOXING", "RUGBY", "RUNNING", "SKATING")
        ),
        CategoryInfo(
            id = "OCEAN LIFE",
            name = "Ocean Life",
            emoji = "🐬",
            themeColor = Color(0xFF00ACC1),
            words = listOf("FISH", "CRAB", "SHARK", "WHALE", "SHRIMP", "SQUID", "OCTOPUS", "TURTLE", "DOLPHIN", "SEAL", "STARFISH")
        ),
        CategoryInfo(
            id = "SCHOOL ITEMS",
            name = "School Items",
            emoji = "🎒",
            themeColor = Color(0xFF5C6BC0),
            words = listOf("PEN", "BOOK", "DESK", "BAG", "RULER", "ERASER", "PENCIL", "PAPER", "CHALK", "BOARD", "MARKER", "GLUE")
        ),
        CategoryInfo(
            id = "FOOD & SNACKS",
            name = "Food & Snacks",
            emoji = "🍕",
            themeColor = Color(0xFFFF7043),
            words = listOf("RICE", "BREAD", "ROTI", "CAKE", "PIZZA", "BURGER", "CHIPS", "COOKIE", "SWEETS", "PASTA", "SOUP", "SALAD")
        ),
        CategoryInfo(
            id = "INSECTS",
            name = "Insects",
            emoji = "🐝",
            themeColor = Color(0xFF9CCC65),
            words = listOf("ANT", "BEE", "FLY", "WASP", "MOTH", "BEETLE", "SPIDER", "CRICKET", "BUG", "FLEA")
        ),
        CategoryInfo(
            id = "SPACE & PLANETS",
            name = "Space & Planets",
            emoji = "🚀",
            themeColor = Color(0xFF7E57C2),
            words = listOf("SUN", "MOON", "MARS", "EARTH", "VENUS", "SATURN", "JUPITER", "STAR", "COMET", "NASA", "ISRO", "ROCKET", "GALAXY")
        ),
        CategoryInfo(
            id = "CLOTHES",
            name = "Clothes",
            emoji = "👕",
            themeColor = Color(0xFF26C6DA),
            words = listOf("SHIRT", "PANTS", "JEANS", "FROCK", "COAT", "JACKET", "SOCKS", "SHOES", "BOOTS", "CAP", "HAT", "GLOVES", "SCARF")
        )
    )

    fun getCategoryById(id: String): CategoryInfo {
        return categories.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: categories.first()
    }
}
