package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CategoryProgressDao {
    @Query("SELECT * FROM category_progress")
    fun getAllProgress(): Flow<List<CategoryProgressEntity>>

    @Query("SELECT * FROM category_progress WHERE categoryId = :categoryId")
    suspend fun getProgressForCategory(categoryId: String): CategoryProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(progress: CategoryProgressEntity)

    @Query("SELECT SUM(highScore) FROM category_progress")
    fun getTotalScoreFlow(): Flow<Int?>

    @Query("SELECT SUM(wordsFound) FROM category_progress")
    fun getTotalWordsFoundFlow(): Flow<Int?>

    @Query("SELECT SUM(starsEarned) FROM category_progress")
    fun getTotalStarsFlow(): Flow<Int?>
}
