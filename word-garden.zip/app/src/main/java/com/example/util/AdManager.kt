package com.example.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

object AdManager {
    private const val TAG = "AdManager"

    // User's configured AdMob Production Unit IDs
    const val BANNER_AD_UNIT_ID = "ca-app-pub-3208154945920359/5065159766"
    const val REWARDED_AD_UNIT_ID = "ca-app-pub-3208154945920359/4873588074"
    const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3208154945920359/9004404770"
    const val APP_OPEN_AD_UNIT_ID = "ca-app-pub-3208154945920359/3938026332"

    // Official Google AdMob Test Unit IDs (used as fallback if production ads have no fill in test environment)
    private const val TEST_APP_OPEN_AD_UNIT_ID = "ca-app-pub-3940256099942544/9257395921"
    private const val TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
    private const val TEST_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"

    // Global state
    var isShowingFullScreenAd = false
        private set

    // --- App Open Ad State ---
    private var appOpenAd: AppOpenAd? = null
    private var isAppOpenLoading = false
    private var appOpenLoadTime: Long = 0L

    // --- Rewarded Ad State ---
    private var rewardedAd: RewardedAd? = null
    private var isRewardedLoading = false

    // --- Interstitial Ad State ---
    private var interstitialAd: InterstitialAd? = null
    private var isInterstitialLoading = false

    // ==========================================
    // APP OPEN AD LOGIC
    // ==========================================

    private fun isAppOpenAdAvailable(): Boolean {
        val wasLoadedWithin4Hours = (System.currentTimeMillis() - appOpenLoadTime) < (4 * 3600 * 1000)
        return appOpenAd != null && wasLoadedWithin4Hours
    }

    /**
     * Called every time the app opens (cold start or returning to foreground)
     */
    fun onAppStart(activity: Activity) {
        if (activity.isFinishing || activity.isDestroyed || isShowingFullScreenAd) {
            return
        }

        if (isAppOpenAdAvailable()) {
            showAppOpenAd(activity)
        } else {
            loadAndShowAppOpenAd(activity)
        }
    }

    /**
     * Preloads the App Open Ad in advance
     */
    fun preloadAppOpenAd(context: Context, useFallbackIfNoFill: Boolean = true) {
        if (isAppOpenAdAvailable() || isAppOpenLoading) return
        isAppOpenLoading = true

        val request = AdRequest.Builder().build()
        AppOpenAd.load(
            context.applicationContext,
            APP_OPEN_AD_UNIT_ID,
            request,
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    Log.d(TAG, "Production App Open Ad loaded successfully.")
                    appOpenAd = ad
                    appOpenLoadTime = System.currentTimeMillis()
                    isAppOpenLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Production App Open Ad failed to load: ${error.message} (code ${error.code})")
                    appOpenAd = null
                    isAppOpenLoading = false

                    if (useFallbackIfNoFill && (error.code == AdRequest.ERROR_CODE_NO_FILL || error.code == AdRequest.ERROR_CODE_INTERNAL_ERROR)) {
                        Log.i(TAG, "Falling back to test App Open Ad unit for testing environment.")
                        loadFallbackAppOpenAd(context)
                    }
                }
            }
        )
    }

    private fun loadFallbackAppOpenAd(context: Context, onLoadedCallback: ((AppOpenAd) -> Unit)? = null) {
        if (isAppOpenLoading) return
        isAppOpenLoading = true

        val request = AdRequest.Builder().build()
        AppOpenAd.load(
            context.applicationContext,
            TEST_APP_OPEN_AD_UNIT_ID,
            request,
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    Log.d(TAG, "Fallback Test App Open Ad loaded successfully.")
                    appOpenAd = ad
                    appOpenLoadTime = System.currentTimeMillis()
                    isAppOpenLoading = false
                    onLoadedCallback?.invoke(ad)
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Fallback App Open Ad failed to load: ${error.message}")
                    appOpenAd = null
                    isAppOpenLoading = false
                }
            }
        )
    }

    private fun loadAndShowAppOpenAd(activity: Activity) {
        if (isAppOpenLoading) return
        isAppOpenLoading = true

        val request = AdRequest.Builder().build()
        AppOpenAd.load(
            activity.applicationContext,
            APP_OPEN_AD_UNIT_ID,
            request,
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    Log.d(TAG, "Production App Open Ad loaded, displaying immediately.")
                    appOpenAd = ad
                    appOpenLoadTime = System.currentTimeMillis()
                    isAppOpenLoading = false
                    if (!activity.isFinishing && !activity.isDestroyed && !isShowingFullScreenAd) {
                        showAppOpenAd(activity)
                    }
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Production App Open Ad failed to load on start: ${error.message} (code ${error.code})")
                    appOpenAd = null
                    isAppOpenLoading = false

                    // If live ad has no inventory fill yet in dev/test, fallback to test ad so the user sees the open ad work
                    if (error.code == AdRequest.ERROR_CODE_NO_FILL || error.code == AdRequest.ERROR_CODE_INTERNAL_ERROR) {
                        loadFallbackAppOpenAd(activity) { loadedAd ->
                            if (!activity.isFinishing && !activity.isDestroyed && !isShowingFullScreenAd) {
                                showAppOpenAd(activity)
                            }
                        }
                    }
                }
            }
        )
    }

    private fun showAppOpenAd(activity: Activity) {
        val ad = appOpenAd ?: return
        if (activity.isFinishing || activity.isDestroyed || isShowingFullScreenAd) return

        isShowingFullScreenAd = true
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                Log.d(TAG, "App Open Ad dismissed.")
                appOpenAd = null
                isShowingFullScreenAd = false
                // Preload the next one immediately for the next app open
                preloadAppOpenAd(activity)
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                Log.w(TAG, "App Open Ad failed to show: ${error.message}")
                appOpenAd = null
                isShowingFullScreenAd = false
                preloadAppOpenAd(activity)
            }

            override fun onAdShowedFullScreenContent() {
                Log.d(TAG, "App Open Ad displayed successfully.")
            }
        }
        ad.show(activity)
    }

    // ==========================================
    // REWARDED AD LOGIC
    // ==========================================

    fun loadRewardedAd(context: Context, useFallback: Boolean = true) {
        if (rewardedAd != null || isRewardedLoading) return
        isRewardedLoading = true

        val request = AdRequest.Builder().build()
        RewardedAd.load(
            context.applicationContext,
            REWARDED_AD_UNIT_ID,
            request,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    Log.d(TAG, "Rewarded ad loaded successfully.")
                    rewardedAd = ad
                    isRewardedLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Rewarded ad failed to load: ${error.message} (code ${error.code})")
                    rewardedAd = null
                    isRewardedLoading = false

                    if (useFallback && (error.code == AdRequest.ERROR_CODE_NO_FILL || error.code == AdRequest.ERROR_CODE_INTERNAL_ERROR)) {
                        loadFallbackRewardedAd(context)
                    }
                }
            }
        )
    }

    private fun loadFallbackRewardedAd(context: Context) {
        if (isRewardedLoading) return
        isRewardedLoading = true

        val request = AdRequest.Builder().build()
        RewardedAd.load(
            context.applicationContext,
            TEST_REWARDED_AD_UNIT_ID,
            request,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    Log.d(TAG, "Fallback test Rewarded ad loaded.")
                    rewardedAd = ad
                    isRewardedLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    isRewardedLoading = false
                }
            }
        )
    }

    fun showRewardedAd(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onAdClosed: () -> Unit = {}
    ) {
        val ad = rewardedAd
        if (ad != null && !activity.isFinishing && !activity.isDestroyed) {
            var earned = false
            isShowingFullScreenAd = true

            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    Log.d(TAG, "Rewarded ad dismissed.")
                    rewardedAd = null
                    isShowingFullScreenAd = false
                    loadRewardedAd(activity)
                    if (earned) {
                        onRewardEarned()
                    } else {
                        onAdClosed()
                    }
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    Log.w(TAG, "Rewarded ad failed to show: ${error.message}")
                    rewardedAd = null
                    isShowingFullScreenAd = false
                    loadRewardedAd(activity)
                    onRewardEarned()
                }

                override fun onAdShowedFullScreenContent() {
                    Log.d(TAG, "Rewarded ad displayed.")
                }
            }

            ad.show(activity) { rewardItem ->
                Log.d(TAG, "User earned reward: ${rewardItem.type} ${rewardItem.amount}")
                earned = true
            }
        } else {
            Log.d(TAG, "Rewarded ad not cached yet, granting reward and preloading next.")
            loadRewardedAd(activity)
            onRewardEarned()
        }
    }

    // ==========================================
    // INTERSTITIAL AD LOGIC
    // ==========================================

    fun loadInterstitialAd(context: Context, useFallback: Boolean = true) {
        if (interstitialAd != null || isInterstitialLoading) return
        isInterstitialLoading = true

        val request = AdRequest.Builder().build()
        InterstitialAd.load(
            context.applicationContext,
            INTERSTITIAL_AD_UNIT_ID,
            request,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    Log.d(TAG, "Interstitial ad loaded successfully.")
                    interstitialAd = ad
                    isInterstitialLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Interstitial ad failed to load: ${error.message} (code ${error.code})")
                    interstitialAd = null
                    isInterstitialLoading = false

                    if (useFallback && (error.code == AdRequest.ERROR_CODE_NO_FILL || error.code == AdRequest.ERROR_CODE_INTERNAL_ERROR)) {
                        loadFallbackInterstitialAd(context)
                    }
                }
            }
        )
    }

    private fun loadFallbackInterstitialAd(context: Context) {
        if (isInterstitialLoading) return
        isInterstitialLoading = true

        val request = AdRequest.Builder().build()
        InterstitialAd.load(
            context.applicationContext,
            TEST_INTERSTITIAL_AD_UNIT_ID,
            request,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    Log.d(TAG, "Fallback test Interstitial ad loaded.")
                    interstitialAd = ad
                    isInterstitialLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    isInterstitialLoading = false
                }
            }
        )
    }

    fun showInterstitialAd(
        activity: Activity,
        onAdDismissed: () -> Unit
    ) {
        val ad = interstitialAd
        if (ad != null && !activity.isFinishing && !activity.isDestroyed) {
            isShowingFullScreenAd = true

            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    Log.d(TAG, "Interstitial ad dismissed.")
                    interstitialAd = null
                    isShowingFullScreenAd = false
                    loadInterstitialAd(activity)
                    onAdDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    Log.w(TAG, "Interstitial ad failed to show: ${error.message}")
                    interstitialAd = null
                    isShowingFullScreenAd = false
                    loadInterstitialAd(activity)
                    onAdDismissed()
                }

                override fun onAdShowedFullScreenContent() {
                    Log.d(TAG, "Interstitial ad shown.")
                }
            }
            ad.show(activity)
        } else {
            Log.d(TAG, "Interstitial ad not cached yet, continuing game.")
            loadInterstitialAd(activity)
            onAdDismissed()
        }
    }

    fun findActivity(context: Context): Activity? {
        var ctx = context
        while (ctx is ContextWrapper) {
            if (ctx is Activity) return ctx
            ctx = ctx.baseContext
        }
        return null
    }
}
